Project Name - Sentiment analysis 
1. Twitter sentiment analysis
2. Text Sentiment Analysis
3. Udemy Course�s reviews sentiment analysis
-----------------------------------------
Project by - 
1. Aniket Bhalerao
2. Ayush Singh
3. Karan Bari
4. Rahul Raj
5. Puneet Kundar
------------------------------------------
this folder contains:
1. data folder (project Report and PPT)
2. static folder (css, js files , required csv files and images)
3. templates folder (html files)
4. app.py (main python file which use flask framework)
5. course_scraping (web srapping code for web scrapping of courses from www.course.com)
-----------------------------------------
In Twitter section of app.py contains api keys of twitter, 
you need to replace it with your twitter api keys.
------------------------------------------
also for succesful running in local host clear browser cache for every run.
------------------------------------------